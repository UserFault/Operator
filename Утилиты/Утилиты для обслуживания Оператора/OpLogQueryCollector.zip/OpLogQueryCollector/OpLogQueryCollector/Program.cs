﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace OpLogQueryCollector
{
    class Program
    {
        static string srcFile = "log.txt";
        static Dictionary<string, Int32> queryDictionary;
        
        static void Main(string[] args)
        {
            Console.WriteLine("Operator query log file parser");
            Console.WriteLine("query file must be log.txt in current directory");
            Console.WriteLine("output file is queresult.txt in current directory");
            
            queryDictionary = new Dictionary<string, int>(256);
            try
            {
                Console.WriteLine("Started...");
                //1 открыть файл читать построчно
                StreamReader sr = new StreamReader(srcFile, Encoding.UTF8, true, 65536);
                while (!sr.EndOfStream)
                {
                    String line = sr.ReadLine().Trim();
                    //2 если строка начинается с QUERY то остальное - поместить в словарь счетчиков.
                    if (!line.StartsWith("QUERY"))
                        continue;
                    //если в словаре уже есть такой элемент, увеличить счетчик на 1.
                    line = line.Substring(5).Trim();
                    if (queryDictionary.ContainsKey(line))
                        queryDictionary[line]++;
                    else
                        queryDictionary.Add(line, 1);
                }
                //в конце файла - вывести весь словарь в файл queresult.txt в той же кодировке
                sr.Close();


                StreamWriter sw = new StreamWriter("queresult.txt", false, Encoding.Default);
                foreach (KeyValuePair<string, Int32> kvp in queryDictionary)
                    sw.WriteLine("{0}; {1}", kvp.Key, kvp.Value);
                sw.Close();
                Console.WriteLine("Processed success");
            }
            catch (Exception e)
            {
                Console.WriteLine();
                Console.WriteLine("Error {0}", e.ToString());
            }
            Console.WriteLine("Press Enter to quit");
            Console.ReadLine();

        }
    }
}
