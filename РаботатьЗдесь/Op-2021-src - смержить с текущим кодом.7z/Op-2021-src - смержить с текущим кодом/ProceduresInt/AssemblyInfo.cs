﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("JS")]
[assembly: AssemblyProduct("Operator")]
[assembly: AssemblyTitle("ProceduresInt")]
[assembly: AssemblyDescription("Operator service procedures")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: AssemblyCopyright("Copyright © JS 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.3.8")]
[assembly: Guid("0c5824a5-be62-45b7-8d8a-71f171d1f239")]
[assembly: AssemblyVersion("1.0.3.8")]
