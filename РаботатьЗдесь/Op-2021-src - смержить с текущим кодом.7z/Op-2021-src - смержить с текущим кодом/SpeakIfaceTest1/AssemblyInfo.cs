﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright("Copyright © Pavel Seliakov 2021")]
[assembly: AssemblyTitle("SpeakIfaceTest1")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Pavel Seliakov")]
[assembly: AssemblyProduct("SpeakIfaceTest1")]
[assembly: Guid("e2eb25e2-d999-4e30-bf8c-f60e09d8e585")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.6.11")]
[assembly: AssemblyVersion("1.0.6.11")]
