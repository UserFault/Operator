﻿// Decompiled with JetBrains decompiler
// Type: SpeakIfaceTest1.Lexicon.DialogConsoleColors
// Assembly: SpeakIfaceTest1, Version=1.0.6.11, Culture=neutral, PublicKeyToken=null
// MVID: 976A6B55-C14F-4871-8987-3516C03DB3B9
// Assembly location: C:\Users\Администратор\Desktop\Щз-1\SpeakIfaceTest1.exe

namespace SpeakIfaceTest1.Lexicon
{
  public enum DialogConsoleColors : uint
  {
    Успех = 2U,
    Предупреждение = 5U,
    Вопрос = 6U,
    Сообщение = 7U,
    ВводПользователя = 15U,
  }
}
