﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright("Copyright © Default 2016")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Default")]
[assembly: AssemblyProduct("FirstProcedures")]
[assembly: AssemblyTitle("FirstProcedures")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("192f1c3a-99f4-4ef0-a637-8ad14b668d7c")]
[assembly: AssemblyFileVersion("1.0.2.2")]
[assembly: AssemblyVersion("1.0.2.2")]
