﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTitle("OperatorLogAnalyzer")]
[assembly: AssemblyDescription("Query counter for Operator project")]
[assembly: AssemblyCompany("Seliakov Pavel")]
[assembly: AssemblyProduct("Operator")]
[assembly: AssemblyCopyright("Copyright © Seliakov Pavel 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("46a4f5e1-1f8b-4b6a-8017-f2a06c890412")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
