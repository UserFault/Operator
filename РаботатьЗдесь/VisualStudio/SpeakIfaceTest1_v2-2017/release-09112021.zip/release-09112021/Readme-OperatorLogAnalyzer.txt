﻿Operator log analyzer - приложение для просмотра логов Оператор-1.
